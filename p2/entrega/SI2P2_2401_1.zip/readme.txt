Autores: Adrián Fernández Amador y Santiago González- Carvajal Centenera.
Pareja: 1.
